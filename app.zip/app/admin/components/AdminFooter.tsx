export default function AdminFooter() {
  return <div>Footer</div>;
}
